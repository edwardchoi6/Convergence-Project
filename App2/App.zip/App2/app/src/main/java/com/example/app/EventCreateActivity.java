package com.example.app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;

public class EventCreateActivity extends AppCompatActivity {

    TextView tvYearEventCreate;
    TextView tvDateEventCreate;
    EditText etCategoryEventCreate;
    EditText etTitleEventCreate;
    TimePicker tpStartTimeEventCreate;
    TimePicker tpFinishTimeEventCreate;
    EditText etContentEventCreate;
    Button btCreateEventCreate;

    String currentYear;
    String currentMonth;
    String currentDate;

    String category;
    String title;
    String content;
    int startTime_hour;
    int startTime_min;
    int finishTime_hour;
    int finishTime_min;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_create);

        tvYearEventCreate = (TextView) findViewById(R.id.tvYearEventCreate);
        tvDateEventCreate = (TextView) findViewById(R.id.tvDateEventCreate);
        etCategoryEventCreate = (EditText) findViewById(R.id.etCategoryEventCreate);
        etTitleEventCreate = (EditText) findViewById(R.id.etTitleEventCreate);
        tpStartTimeEventCreate = (TimePicker) findViewById(R.id.tpStartTimeEventCreate);
        tpFinishTimeEventCreate = (TimePicker) findViewById(R.id.tpFinishTimeEventCreate);
        etContentEventCreate = (EditText) findViewById(R.id.etContentEventCreate);
        btCreateEventCreate = (Button) findViewById(R.id.btCreateEventCreate);

        btCreateEventCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /**
                 * Api call
                 * Send event infos to server
                 * Create & Save Events
                 */
                Intent intent = new Intent(EventCreateActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        tpStartTimeEventCreate.setIs24HourView(true); //12시로 할지, 24시로 할지
        tpFinishTimeEventCreate.setIs24HourView(true);
        tpStartTimeEventCreate.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                startTime_hour = hourOfDay;
                startTime_min = minute;
            }
        });
        tpFinishTimeEventCreate.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                finishTime_hour = hourOfDay;
                finishTime_min = minute;
            }
        });

        Intent intent = getIntent();
        Bundle fromEventListBundle = new Bundle(intent.getBundleExtra("EventCreateBundle"));
        currentYear = fromEventListBundle.getString("year");
        currentMonth = fromEventListBundle.getString("month");
        currentDate = fromEventListBundle.getString("date");

        setHeaderText();

        saveEventInfo();
    }

    public void setHeaderText() {
        tvYearEventCreate.setText(currentYear);
        tvDateEventCreate.setText((Integer.parseInt(currentMonth)+1) +"월 " +  currentDate);
    }

    //Api
    //사용자가 입력한 값들을 가져오는 역할
    public void saveEventInfo() {
        category = etCategoryEventCreate.getText().toString();
        title = etTitleEventCreate.getText().toString();
        content = etContentEventCreate.getText().toString();
    }
}
