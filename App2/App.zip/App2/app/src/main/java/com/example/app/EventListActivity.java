package com.example.app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class EventListActivity extends AppCompatActivity { //뒤로가기는 manifest에서 구현되었다. android:parentActivityName

    TextView tvYearEventList;
    TextView tvDateEventList;
    ListView lvEventList;

    ArrayList<EventItem> eventItems;
    EventAdapter eventAdapter;

    String currentYear;
    String currentMonth;
    String currentDate;

    CalendarAdapter calendarAdapter;

    Button btEventCreation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_list);

        tvYearEventList = (TextView) findViewById(R.id.tvYearEventList);
        tvDateEventList = (TextView) findViewById(R.id.tvDateEventList);
        lvEventList = (ListView) findViewById(R.id.lvEventList);
        btEventCreation = (Button) findViewById(R.id.btEventCreation);

        init(); //초기화 함수

        eventAdapter = new EventAdapter(this, eventItems);
        lvEventList.setAdapter(eventAdapter); //ListView에 내장된 method

        calendarAdapter = new CalendarAdapter(this);
        lvEventList.setAdapter(eventAdapter);

        Intent intent = getIntent();
        Bundle fromMainBundle = intent.getBundleExtra("eventListBundle");
        currentYear = fromMainBundle.getString("year");
        currentMonth = fromMainBundle.getString("month");
        currentDate = fromMainBundle.getString("date");

        setHeaderText(); //year랑 dateview라고 써 있는 거에 실제로 값이 들어가야 되니깐

        //toEventInfoBundle과 toEventCreateBundle은 같은 내용이다.
        final Bundle toEventInfoBundle = new Bundle();
        toEventInfoBundle.putString("year", currentYear);
        toEventInfoBundle.putString("month", currentMonth);
        toEventInfoBundle.putString("date", currentDate);

        final Bundle toEventCreateBundle = new Bundle();
        toEventCreateBundle.putString("year", currentYear);
        toEventCreateBundle.putString("month", currentMonth);
        toEventCreateBundle.putString("date", currentDate);

        lvEventList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(EventListActivity.this, EventInfoActivity.class);
                intent.putExtra("EventInfoBundle", toEventInfoBundle);
                startActivity(intent);
            }
        });

        btEventCreation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EventListActivity.this, EventCreateActivity.class);
                intent.putExtra("EventCreateBundle", toEventCreateBundle);
                startActivity(intent);
            }
        });

    }

    //onCreate될 때 필요한 것들 (View와 class 변수들을 mapping)
    public void init() {
        eventItems = new ArrayList<EventItem>();
        eventItems.add(new EventItem("동아리 모임"));
        eventItems.add(new EventItem("수학 과제"));
        eventItems.add(new EventItem("퀴즈"));
    }

    public void setHeaderText() {

        tvYearEventList.setText(currentYear);
        tvYearEventList.setText(Integer.parseInt(currentMonth) + 1 + "월 " + currentDate + "일"); //여기서는 달이 바뀔 일이 없으므로 그냥
    }
}
