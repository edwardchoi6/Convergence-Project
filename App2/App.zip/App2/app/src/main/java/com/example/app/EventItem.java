package com.example.app;

public class EventItem {

    String event;

    public EventItem(String event) {
        this.event = event;
    }

    public String getEvent() {
        return event;
    }

}
